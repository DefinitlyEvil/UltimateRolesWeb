UltimateRoles Web
=================

The website part of UltimateRolesPlugin, a complete solution for role/perk management for Bukkit/Spigot servers, written in PHP. 

![screenshot](https://github.com/DragonetMC/UltimateRolesWeb/raw/master/assets/edit-role.jpg)

## Still under development
