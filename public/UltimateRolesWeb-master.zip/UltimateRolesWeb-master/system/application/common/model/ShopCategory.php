<?php


namespace app\common\model;


use think\Model;

class ShopCategory extends Model {
    protected $table = "shop_categories";
}