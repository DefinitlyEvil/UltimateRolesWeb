<?php


namespace app\common\model;


use think\Model;

class LoginToken extends Model {
    protected $table = "login_tokens";

}