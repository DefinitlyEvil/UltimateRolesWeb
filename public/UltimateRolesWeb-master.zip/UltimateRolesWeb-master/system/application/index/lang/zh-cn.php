<?php
return [
    "featured" => "推荐商品",
    "player_count" => "玩家总数",
    "role_instance_count" => "角色统计",
];
