<?php
return [
    "featured" => "Featured Items",
    "player_count" => "Total players",
    "role_instance_count" => "Roles applied to players",
];
