<?php
return [
    /**
     * login password for admin panel
     */
    "password" => sha1("UltimateRolesAdmin")
];
