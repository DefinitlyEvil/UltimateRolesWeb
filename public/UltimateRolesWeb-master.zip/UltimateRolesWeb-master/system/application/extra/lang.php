<?php

return [
    "success" => "Success! ",

    // ERRORS
    "invalid_data" => "Invalid data! ",
    "player_not_found" => "can not find player",
    "perk_not_found" => "can not find the perk! ",
];
