<?php
return [
    "server_name" => "My Server",
    "server_slogan" => "a Minecraft server using UltimateRoles",

    "currency_unit" => "GamePoint",
];
