<?php
return [
    /*
     * secret for Bukkit/Spigot plugins to communicate with the API,
     * also can be used as ServerAPI
     */
    "secret_plugin" => "CHANGE_ME",

    /*
     * secret for accessing admin API
     *
     * notice: this is NOT admin login password,
     *     to change admin password, edit /application/extra/admin.php
     */
    "secret_admin" => "CHANGE_ME",
];
