<?php

return [
    "login_head" => "角色系统和在线商店",
    "login_sub" => "这个服务器使用的是 UltimateRoles 角色系统",
    "login_title" => "玩家登陆",
];
