<?php

return [
    "login_head" => "Role System and Web Shop",
    "login_sub" => "this server is using UltimateRoles",
    "login_title" => "Login",
];
